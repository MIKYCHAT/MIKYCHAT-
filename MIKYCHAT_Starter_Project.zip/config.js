/*
  MIKYCHAT public browser configuration.
  Use only your Supabase project URL and publishable/anon key here.
  NEVER put a service_role key, LiveKit API secret, payment secret, or other server secret in this file.
*/
window.MIKYCHAT_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  SUPABASE_PUBLISHABLE_KEY: "PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE"
};
