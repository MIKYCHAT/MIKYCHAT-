-- MIKYCHAT starter database setup.
-- Review before running. Existing tables are not dropped.
-- Run in Supabase Dashboard > SQL Editor.
-- These policies let each signed-in user read/update their own profile and submit
-- a pending creator application only for their own auth user ID.
-- Do not store ID documents or sensitive identity numbers in these tables.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

grant select, insert, update on public.profiles to authenticated;

drop policy if exists "Users can read their own profile" on public.profiles;
create policy "Users can read their own profile"
on public.profiles for select to authenticated
using (auth.uid() = id);

drop policy if exists "Users can create their own profile" on public.profiles;
create policy "Users can create their own profile"
on public.profiles for insert to authenticated
with check (auth.uid() = id);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
on public.profiles for update to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

create table if not exists public.creator_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  country text not null,
  bio text,
  contact_email text not null,
  status text not null default 'pending'
    check (status in ('pending', 'under_review', 'approved', 'rejected')),
  created_at timestamptz not null default now()
);

alter table public.creator_applications
  add column if not exists user_id uuid references auth.users(id) on delete cascade;
alter table public.creator_applications
  add column if not exists display_name text;
alter table public.creator_applications
  add column if not exists country text;
alter table public.creator_applications
  add column if not exists bio text;
alter table public.creator_applications
  add column if not exists contact_email text;
alter table public.creator_applications
  add column if not exists status text not null default 'pending';
alter table public.creator_applications
  add column if not exists created_at timestamptz not null default now();

alter table public.creator_applications enable row level security;
grant select, insert on public.creator_applications to authenticated;

drop policy if exists "Users can submit their own pending creator application" on public.creator_applications;
create policy "Users can submit their own pending creator application"
on public.creator_applications for insert to authenticated
with check (auth.uid() = user_id and status = 'pending');

drop policy if exists "Users can view their own creator applications" on public.creator_applications;
create policy "Users can view their own creator applications"
on public.creator_applications for select to authenticated
using (auth.uid() = user_id);

notify pgrst, 'reload schema';
