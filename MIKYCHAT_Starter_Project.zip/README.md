# MIKYCHAT Starter Project

This project is a simple, separated-file starter for the MIKYCHAT website.

## Files

- `index.html` — page structure and modal forms.
- `styles.css` — responsive dark purple/pink design.
- `config.js` — public Supabase project URL and publishable key.
- `app.js` — browser interactions, Supabase Auth, confirmation resend, and creator application submission.
- `supabase-setup.sql` — starter tables and row-level security policies.

## Important safety notes

- Only put your Supabase **project URL** and **publishable key** in `config.js`.
- Never put a Supabase `service_role` key, LiveKit API secret, payment secret, or other private secret in public website files.
- This starter does not yet implement actual live video, formal age/identity verification, moderation workflows, tips, or payouts.
- The age checkbox is not identity or age verification.
- Do not collect or store identity documents in the creator application table.
- Before public launch, add legal pages, reporting/blocking/moderation tools, secure verification, server-side streaming token creation, and a payment provider that approves your use case and countries.

## Setup

### 1. Configure Supabase in `config.js`

Open `config.js` and replace the two placeholder strings with your Supabase project's URL and publishable key. You can find them in your Supabase project's API/Data API settings.

The URL should look like `https://your-project-ref.supabase.co`.
Use the publishable key (or legacy anon key if your project uses that). Do not use a service-role key.

### 2. Run the SQL

In Supabase, open **SQL Editor → New query**. Review `supabase-setup.sql`, paste it, and run it. If your project already has policies or tables, review the statements carefully first. This script does not drop existing tables, but it does replace policies with the same names.

### 3. Set up email confirmation

In Supabase, open **Authentication → URL Configuration**:
- Add your published website URL to **Site URL**.
- Add your published website URL to **Redirect URLs**.
- For local testing, add the local URL only if you use a local development server.

In **Authentication → Providers → Email**, keep email confirmation enabled for production. Make sure SMTP/email delivery is configured and check spam folders. The website has a **Resend confirmation email** button on the login form.

### 4. Upload files to GitHub

Put all five files in the same folder/repository root:
- `index.html`
- `styles.css`
- `config.js`
- `app.js`
- `supabase-setup.sql`
- `README.md`

Commit and push to your GitHub repository. If using GitHub Pages, set Pages to deploy from the `main` branch and `/(root)`.

### 5. Test

1. Open the published website.
2. Create an account using an email inbox you can access.
3. Check inbox and spam for confirmation.
4. If no email arrives, use **Log in → Resend confirmation email**.
5. Confirm the email, then log in.
6. Test creator application submission.

## Next stages

1. Add a profile creation workflow if desired.
2. Add admin-only creator review and secure third-party age/identity verification.
3. Add a server-side Edge Function that issues short-lived LiveKit tokens only to approved creators.
4. Add LiveKit room creation/end-live workflow.
5. Add payment provider integration, verified webhooks, ledger, and payout checks.
