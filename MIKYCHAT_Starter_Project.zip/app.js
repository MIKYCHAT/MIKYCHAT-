(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const toast = $("toast");
  let toastTimer;
  function showToast(message) {
    toast.textContent = message;
    toast.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.add("hidden"), 4000);
  }

  $("year").textContent = new Date().getFullYear();

  // Age gate is only a basic front-end notice, not age verification.
  const ageModal = $("ageModal");
  try {
    if (sessionStorage.getItem("mikychat_age_confirmed") === "yes") ageModal.classList.add("hidden");
  } catch (_) {}
  $("confirmAge").addEventListener("click", () => {
    try { sessionStorage.setItem("mikychat_age_confirmed", "yes"); } catch (_) {}
    ageModal.classList.add("hidden");
  });
  $("leaveSite").addEventListener("click", () => {
    ageModal.querySelector(".modalbox").innerHTML = "<h2>Access not granted</h2><p>You must be at least 18 to enter MIKYCHAT.</p>";
  });

  // Sample profile filtering.
  const search = $("searchInput");
  let currentFilter = "all";
  function filterCards() {
    const query = search.value.trim().toLowerCase();
    let count = 0;
    document.querySelectorAll(".creator").forEach(card => {
      const visible = card.dataset.name.includes(query) &&
        (currentFilter === "all" || card.dataset.category === currentFilter);
      card.classList.toggle("hidden", !visible);
      if (visible) count++;
    });
    $("emptyState").classList.toggle("hidden", count !== 0);
  }
  search.addEventListener("input", filterCards);
  document.querySelectorAll(".filter").forEach(button => button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    currentFilter = button.dataset.filter;
    filterCards();
  }));

  const config = window.MIKYCHAT_CONFIG || {};
  const configured = config.SUPABASE_URL && config.SUPABASE_PUBLISHABLE_KEY &&
    !config.SUPABASE_URL.includes("PASTE_") && !config.SUPABASE_PUBLISHABLE_KEY.includes("PASTE_");
  if (!window.supabase || !configured) {
    showToast("Add your Supabase URL and publishable key in config.js to enable accounts.");
    ["loginBtn","joinBtn","creatorBtn"].forEach(id => $(id).addEventListener("click", () => {
      openAuth("signup");
      setAuthMessage("First add your Supabase project URL and publishable key in config.js, then reload this page.", true);
    }));
    return;
  }

  const client = window.supabase.createClient(config.SUPABASE_URL, config.SUPABASE_PUBLISHABLE_KEY, {
    auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true }
  });
  const authModal = $("authModal");
  const authForm = $("authForm");
  const authEmail = $("authEmail");
  const authPassword = $("authPassword");
  const authPasswordConfirm = $("authPasswordConfirm");
  const adultConsent = $("adultConsent");
  const authSubmit = $("authSubmit");
  const authMessage = $("authMessage");
  const resendButton = $("resendConfirmation");
  let authMode = "signup";

  function setAuthMessage(message, isError = false) {
    authMessage.textContent = message;
    authMessage.style.color = isError ? "#ff8cae" : "#65e6b0";
  }
  function setAuthMode(mode) {
    authMode = mode;
    const signup = mode === "signup";
    $("authTitle").textContent = signup ? "Create your account" : "Welcome back";
    $("authIntro").textContent = signup
      ? "Register with an email inbox you can access."
      : "Log in with the email and password you registered with.";
    authSubmit.textContent = signup ? "Create account" : "Log in";
    $("confirmPasswordLabel").classList.toggle("hidden", !signup);
    authPassword.autocomplete = signup ? "new-password" : "current-password";
    authPasswordConfirm.required = signup;
    adultConsent.required = signup;
    $("adultConsentLabel").classList.toggle("hidden", !signup);
    $("forgotPassword").classList.toggle("hidden", signup);
    resendButton.classList.toggle("hidden", signup);
    $("switchToLogin").classList.toggle("hidden", !signup);
    $("switchToSignup").classList.toggle("hidden", signup);
    setAuthMessage("");
  }
  function openAuth(mode) {
    setAuthMode(mode);
    authModal.classList.remove("hidden");
    authEmail.focus();
  }
  function closeAuth() { authModal.classList.add("hidden"); }
  $("loginBtn").addEventListener("click", () => openAuth("login"));
  $("joinBtn").addEventListener("click", () => openAuth("signup"));
  $("closeAuth").addEventListener("click", closeAuth);
  $("switchToLogin").addEventListener("click", () => setAuthMode("login"));
  $("switchToSignup").addEventListener("click", () => setAuthMode("signup"));

  $("creatorBtn").addEventListener("click", async () => {
    const { data, error } = await client.auth.getSession();
    if (error || !data.session) {
      openAuth("signup");
      setAuthMessage("Create an account and confirm your email before applying.");
      return;
    }
    $("modelModal").classList.remove("hidden");
  });

  authForm.addEventListener("submit", async event => {
    event.preventDefault();
    const email = authEmail.value.trim();
    const password = authPassword.value;
    authSubmit.disabled = true;
    setAuthMessage("");
    try {
      if (authMode === "signup") {
        if (password !== authPasswordConfirm.value) throw new Error("Your passwords do not match.");
        if (!adultConsent.checked) throw new Error("Please confirm that you are 18 or older.");
        const { data, error } = await client.auth.signUp({
          email, password,
          options: { emailRedirectTo: window.location.origin + window.location.pathname }
        });
        if (error) throw error;
        if (data.session) {
          setAuthMessage("Account created and you are signed in.");
          await updateAccountUI(data.session);
          showToast("Welcome to MIKYCHAT.");
          setTimeout(closeAuth, 1000);
        } else {
          setAuthMessage("Account created. Check your inbox and spam folder for the confirmation link. If no email arrives, use Resend confirmation email from the Log in screen.");
        }
      } else {
        const { data, error } = await client.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setAuthMessage("You are logged in.");
        await updateAccountUI(data.session);
        showToast("You are logged in to MIKYCHAT.");
        setTimeout(closeAuth, 800);
      }
    } catch (error) {
      setAuthMessage(error.message || "Something went wrong. Please try again.", true);
    } finally {
      authSubmit.disabled = false;
    }
  });

  resendButton.addEventListener("click", async () => {
    const email = authEmail.value.trim();
    if (!email) {
      setAuthMessage("Enter the email address you registered with first.", true);
      return;
    }
    resendButton.disabled = true;
    try {
      const { error } = await client.auth.resend({
        type: "signup",
        email,
        options: { emailRedirectTo: window.location.origin + window.location.pathname }
      });
      if (error) throw error;
      setAuthMessage("If this address has an unconfirmed account, a confirmation email should arrive. Check spam too.");
    } catch (error) {
      setAuthMessage(error.message || "Could not resend confirmation email.", true);
    } finally {
      resendButton.disabled = false;
    }
  });

  $("forgotPassword").addEventListener("click", async () => {
    const email = authEmail.value.trim();
    if (!email) {
      setAuthMessage("Enter your email address first.", true);
      return;
    }
    const button = $("forgotPassword");
    button.disabled = true;
    try {
      const { error } = await client.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + window.location.pathname
      });
      if (error) throw error;
      setAuthMessage("If the account exists, a password reset link will be sent. Check spam too.");
    } catch (error) {
      setAuthMessage(error.message || "Could not request a password reset.", true);
    } finally {
      button.disabled = false;
    }
  });

  async function updateAccountUI(session) {
    const user = session?.user;
    let displayName = user?.user_metadata?.display_name || user?.email?.split("@")[0] || "MIKYCHAT User";
    if (user) {
      const { data: profile, error } = await client.from("profiles")
        .select("display_name, username").eq("id", user.id).maybeSingle();
      if (!error && profile) displayName = profile.display_name || displayName;
    }
    $("accountLabel").textContent = user ? displayName : "";
    $("accountLabel").title = user?.email || "";
    $("accountLabel").classList.toggle("hidden", !user);
    $("loginBtn").classList.toggle("hidden", !!user);
    $("joinBtn").classList.toggle("hidden", !!user);
    $("logoutBtn").classList.toggle("hidden", !user);
  }
  $("logoutBtn").addEventListener("click", async () => {
    const { error } = await client.auth.signOut();
    if (error) showToast(error.message);
    else { await updateAccountUI(null); showToast("You have logged out."); }
  });

  client.auth.getSession().then(({ data }) => updateAccountUI(data.session));
  client.auth.onAuthStateChange((_event, session) => { updateAccountUI(session); });

  $("closeModel").addEventListener("click", () => $("modelModal").classList.add("hidden"));
  $("modelForm").addEventListener("submit", async event => {
    event.preventDefault();
    const message = $("modelMessage");
    const button = $("modelSubmit");
    const { data: sessionData, error: sessionError } = await client.auth.getSession();
    if (sessionError || !sessionData.session) {
      message.textContent = "Please log in and confirm your email first.";
      return;
    }
    if (! $("modelAdultConsent").checked) {
      message.textContent = "Please confirm you are at least 18.";
      return;
    }
    button.disabled = true;
    message.textContent = "Submitting application…";
    const application = {
      user_id: sessionData.session.user.id,
      display_name: $("modelDisplayName").value.trim(),
      country: $("modelCountry").value.trim(),
      bio: $("modelBio").value.trim(),
      contact_email: $("modelContactEmail").value.trim(),
      status: "pending"
    };
    try {
      const { error } = await client.from("creator_applications").insert(application);
      if (error) throw error;
      message.textContent = "Application received and pending review. This is not age or identity verification.";
      $("modelForm").reset();
    } catch (error) {
      message.textContent = error.message || "Could not submit. Check the database setup and security policy.";
    } finally {
      button.disabled = false;
    }
  });

  ["termsLink","privacyLink","supportLink"].forEach(id => $(id).addEventListener("click", event => {
    event.preventDefault();
    showToast("Terms, privacy, and support pages must be completed before production launch.");
  }));
})();